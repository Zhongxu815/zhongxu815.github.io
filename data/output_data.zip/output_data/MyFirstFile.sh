#!/bin/bash
# select the country with the highest motality
# usage: script.sh
grep Infant_mortality OECD_Countries_Full.txt |grep 2012|sort -n -k6|tail -n 1 > CountryWithHighstMortality.txt
